import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StudentManagementSystem {
    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/student_management_system";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Bv@9741303504";

    // Method to establish a database connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    // Method to add a new student to the database
    public static void addStudent(Student student) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO Students (student_id, name, age, email) VALUES (?, ?, ?, ?)")) {
            statement.setInt(1, student.getStudentId());
            statement.setString(2, student.getName());
            statement.setInt(3, student.getAge());
            statement.setString(4, student.getEmail());

            statement.executeUpdate();
            System.out.println("New student added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add a new course to the database
    public static void addCourse(Course course) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO Courses (course_id, name, credits) VALUES (?, ?, ?)")) {
            statement.setInt(1, course.getCourseId());
            statement.setString(2, course.getName());
            statement.setInt(3, course.getCredits());

            statement.executeUpdate();
            System.out.println("New course added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to enroll a student in a course
    public static void enrollStudent(int studentId, int courseId) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO Enrollments (student_id, course_id) VALUES (?, ?)")) {
            statement.setInt(1, studentId);
            statement.setInt(2, courseId);

            statement.executeUpdate();
            System.out.println("Student enrolled in the course successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update a student's grade for a course
    public static void updateGrade(int enrollmentId, int grade) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE Enrollments SET grade = ? WHERE enrollment_id = ?")) {
            statement.setInt(1, grade);
            statement.setInt(2, enrollmentId);

            statement.executeUpdate();
            System.out.println("Student's grade updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Example usage
        Student student = new Student(4, "Emily Green", 19, "emily.green@example.com");
        addStudent(student);

        Course course = new Course(4, "English", 3);
        addCourse(course);

        enrollStudent(4, 3);

        updateGrade(4, 80);
    }
}

class Student {
    private int studentId;
    private String name;
    private int age;
    private String email;

    public Student(int studentId, String name, int age, String email) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
    }

    public int getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }
}

class Course {
    private int courseId;
    private String name;
    private int credits;

    public Course(int courseId, String name, int credits) {
        this.courseId = courseId;
        this.name = name;
        this.credits = credits;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getName() {
        return name;
    }

    public int getCredits() {
        return credits;
    }
}
