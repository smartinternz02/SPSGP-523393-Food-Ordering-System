CREATE DATABASE student_management_system;
CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(255),
    age INT,
    email VARCHAR(255)
);
CREATE TABLE Courses (
    course_id INT PRIMARY KEY,
    name VARCHAR(255),
    credits INT
);
CREATE TABLE Enrollments (
    enrollment_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    grade INT,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);
INSERT INTO Students (student_id, name, age, email)
VALUES (1, 'John Smith', 20, 'john.smith@example.com'),
       (2, 'Jane Doe', 22, 'jane.doe@example.com'),
       (3, 'David Brown', 21, 'david.brown@example.com');
INSERT INTO Courses (course_id, name, credits)
VALUES (1, 'Math', 3),
       (2, 'Science', 4),
       (3, 'History', 3);
INSERT INTO Enrollments (enrollment_id, student_id, course_id, grade)
VALUES (1, 1, 1, 85),
       (2, 1, 2, 90),
       (3, 2, 2, 88),
       (4, 3, 3, 76);



